import { $ as resetNativeMemoryStats, B as NapiResolveOptions, E as BindingViteManifestPluginConfig, F as IsolatedDeclarationsResult, G as ResolverFactory, P as IsolatedDeclarationsOptions, Q as moduleRunnerTransform, W as ResolveResult, X as isolatedDeclaration, Y as getNativeMemoryStats, Z as isolatedDeclarationSync, b as BindingTsconfigRawOptions, f as BindingModuleInfo, h as BindingRebuildStrategy, i as BindingClientHmrUpdate, j as BindingViteTransformPluginConfig, n as BindingBundleAnalyzerPluginConfig, p as BindingNativeMemoryStats, r as BindingBundleState, u as BindingLazyChunkOutput, y as BindingTsconfigCompilerOptions } from "./shared/binding-CwA4xu8x.mjs";
import { $ as defineParallelPlugin, I as BuiltinPlugin, Qt as RolldownOutput, Ut as OutputOptions, en as freeExternalMemory, l as InputOptions, qt as StringOrRegExp, ut as NormalizedOutputOptions } from "./shared/define-config-BLptERXo.mjs";
import { a as MinifyOptions$1, c as minifySync$1, d as parse$1, f as parseSync$1, i as transformSync$1, l as ParseResult$1, m as resolveTsconfig, n as TransformResult$1, o as MinifyResult$1, p as TsconfigCache$1, r as transform$1, s as minify$1, t as TransformOptions$1, u as ParserOptions$1 } from "./shared/transform-BH7GdGwN.mjs";
import { a as viteDynamicImportVarsPlugin, c as viteLoadFallbackPlugin, d as viteReporterPlugin, f as viteResolvePlugin, i as viteBuildImportAnalysisPlugin, l as viteModulePreloadPolyfillPlugin, n as isolatedDeclarationPlugin, o as viteImportGlobPlugin, p as viteWebWorkerPostPlugin, r as oxcRuntimePlugin, s as viteJsonPlugin, u as viteReactRefreshWrapperPlugin } from "./shared/constructors-D9cRAoTT.mjs";
//#region src/api/dev/dev-options.d.ts
type DevOnHmrUpdates = (result: Error | {
  updates: BindingClientHmrUpdate[];
  changedFiles: string[];
}) => void | Promise<void>;
type DevOnOutput = (result: Error | RolldownOutput) => void | Promise<void>;
type DevOnAdditionalAssets = (output: RolldownOutput) => void | Promise<void>;
interface DevWatchOptions {
  /**
   * If `false`, no file system watcher is started, so file changes are never
   * picked up and no rebuild or HMR update is triggered on their own.
   * @default true
   */
  enabled?: boolean;
  /**
   * If `true`, files are not written to disk.
   * @default false
   */
  skipWrite?: boolean;
  /**
   * If `true`, use polling instead of native file system events for watching.
   * @default false
   */
  usePolling?: boolean;
  /**
   * Poll interval in milliseconds (only used when usePolling is true).
   * @default 100
   */
  pollInterval?: number;
  /**
   * If `true`, use debounced watcher. If `false`, use non-debounced watcher for immediate responses.
   * @default true
   */
  useDebounce?: boolean;
  /**
   * Debounce duration in milliseconds (only used when useDebounce is true).
   * @default 10
   */
  debounceDuration?: number;
  /**
   * Whether to compare file contents for poll-based watchers (only used when usePolling is true).
   * When enabled, poll watchers will check file contents to determine if they actually changed.
   * @default false
   */
  compareContentsForPolling?: boolean;
  /**
   * Tick rate in milliseconds for debounced watchers (only used when useDebounce is true).
   * Controls how frequently the debouncer checks for events to process.
   * When not specified, the debouncer will auto-select an appropriate tick rate (1/4 of the debounce duration).
   * @default undefined (auto-select)
   */
  debounceTickRate?: number;
  /**
   * Filter to limit which discovered files are registered with the file watcher.
   *
   * Strings are treated as glob patterns.
   *
   * @default []
   */
  include?: StringOrRegExp | StringOrRegExp[];
  /**
   * Filter to prevent discovered files from being registered with the file watcher.
   *
   * Strings are treated as glob patterns.
   *
   * @default []
   */
  exclude?: StringOrRegExp | StringOrRegExp[];
}
interface DevOptions {
  onHmrUpdates?: DevOnHmrUpdates;
  onOutput?: DevOnOutput;
  /**
   * Called with assets emitted while generating an HMR patch or compiling a
   * lazy entry (e.g. an image newly imported by the changed/lazy module).
   *
   * These never go through {@link onOutput}, so a consumer that serves built
   * files (e.g. Vite's bundled dev server) must register this to receive them
   * and write them to its in-memory file store before the client requests them.
   */
  onAdditionalAssets?: DevOnAdditionalAssets;
  /**
   * Strategy for triggering rebuilds after HMR updates.
   * - `'always'`: Always trigger a rebuild after HMR updates
   * - `'never'`: Never trigger rebuild after HMR updates. The server no longer
   *   decides full reloads, so there is no `'auto'` upgrade anymore; pull fresh
   *   bundle output explicitly (e.g. `ensureLatestBuildOutput`) when needed.
   * @default 'never'
   */
  rebuildStrategy?: "always" | "never";
  watch?: DevWatchOptions;
  /**
   * Whether the `hotUpdate` plugin hook is called. `experimental.devMode.hotUpdate` also turns it on.
   * @default false
   */
  hotUpdate?: boolean;
}
//#endregion
//#region src/api/dev/dev-engine.d.ts
/**
 * The part of the binding engine the module graph reads from.
 *
 * Typed structurally instead of as `BindingDevEngine`: a public constructor
 * parameter type is emitted into the public dts, and naming the binding class
 * there would pull the whole binding type chain into the public surface.
 */
interface ModuleGraphSource {
  getModuleInfo(moduleId: string): BindingModuleInfo | null;
  getModuleIds(): Array<string>;
}
/** Read-only view over the engine's module graph, kept current across rebuilds. */
declare class DevEngineModuleGraph {
  #private;
  constructor(inner: ModuleGraphSource);
  /**
   * Get additional information about the module in question.
   *
   * @returns Module information for that module. `null` if the module could not be found.
   */
  getModuleInfo(moduleId: string): BindingModuleInfo | null;
  /**
   * Get all module ids in the current module graph.
   *
   * @returns An array of module ids.
   */
  getModuleIds(): string[];
}
export declare class DevEngine {
  #private;
  readonly moduleGraph: DevEngineModuleGraph;
  static create(inputOptions: InputOptions, outputOptions?: OutputOptions, devOptions?: DevOptions): Promise<DevEngine>;
  private constructor();
  run(): Promise<void>;
  ensureCurrentBuildFinish(): Promise<void>;
  getBundleState(): Promise<BindingBundleState>;
  ensureLatestBuildOutput(): Promise<void>;
  triggerFullBuild(): void;
  /**
   * Client-connect signal (the clientId hello): creates the per-client session
   * with an empty ship map. Reconnects arrive as fresh clientIds.
   */
  registerClient(clientId: string): Promise<void>;
  /**
   * Delivery notification for the payload `filename`. Call it when the client
   * reports that it ran the payload (Vite appends a
   * `__rolldown_runtime__.payloadDelivered(filename)` statement to every patch
   * and lazy chunk). A completed HTTP response is not enough: the bytes may not
   * have evaluated yet. Records the payload's modules as shipped to that client.
   */
  notifyPayloadDelivered(filename: string): Promise<void>;
  removeClient(clientId: string): Promise<void>;
  close(): Promise<void>;
  /**
   * Compile a lazy entry module and return HMR-style patch code.
   *
   * This is called when a dynamically imported module is first requested at runtime.
   * The module was previously stubbed with a proxy, and now we need to compile the
   * actual module and its dependencies.
   *
   * @param moduleId - The absolute file path of the module to compile
   * @param clientId - The client ID requesting this compilation
   * @returns The compiled chunk: its code plus the filename whose delivery the
   * dev server reports via {@link notifyPayloadDelivered}
   */
  compileEntry(moduleId: string, clientId: string): Promise<BindingLazyChunkOutput>;
}
//#endregion
//#region src/api/dev/index.d.ts
export declare const dev: typeof DevEngine.create;
//#endregion
//#region src/api/experimental.d.ts
/**
 * This is an experimental API. Its behavior may change in the future.
 *
 * - Calling this API will only execute the `scan/build` stage of rolldown.
 * - `scan` will clean up all resources automatically, but if you want to ensure timely cleanup, you need to wait for the returned promise to resolve.
 *
 * @example To ensure cleanup of resources, use the returned promise to wait for the scan to complete.
 * ```ts
 * import { scan } from 'rolldown/api/experimental';
 *
 * const cleanupPromise = await scan(...);
 * await cleanupPromise;
 * // Now all resources have been cleaned up.
 * ```
 */
export declare const scan: (rawInputOptions: InputOptions, rawOutputOptions?: {}) => Promise<Promise<void>>;
//#endregion
//#region src/builtin-plugin/alias-plugin.d.ts
type ViteAliasPluginConfig = {
  entries: {
    find: string | RegExp;
    replacement: string;
  }[];
};
export declare function viteAliasPlugin(config: ViteAliasPluginConfig): BuiltinPlugin;
//#endregion
//#region src/builtin-plugin/bundle-analyzer-plugin.d.ts
/**
 * A plugin that analyzes bundle composition and generates detailed reports.
 *
 * The plugin outputs a file containing detailed information about:
 * - All chunks and their relationships
 * - Modules bundled in each chunk
 * - Import dependencies between chunks
 * - Reachable modules from each entry point
 *
 * @example
 * ```js
 * import { bundleAnalyzerPlugin } from 'rolldown/experimental';
 *
 * export default {
 *   plugins: [
 *     bundleAnalyzerPlugin()
 *   ]
 * }
 * ```
 *
 * @example
 * **Custom filename**
 * ```js
 * import { bundleAnalyzerPlugin } from 'rolldown/experimental';
 *
 * export default {
 *   plugins: [
 *     bundleAnalyzerPlugin({
 *       fileName: 'bundle-analysis.json'
 *     })
 *   ]
 * }
 * ```
 *
 * @example
 * **LLM-friendly markdown output**
 * ```js
 * import { bundleAnalyzerPlugin } from 'rolldown/experimental';
 *
 * export default {
 *   plugins: [
 *     bundleAnalyzerPlugin({
 *       format: 'md'
 *     })
 *   ]
 * }
 * ```
 */
export declare function bundleAnalyzerPlugin(config?: BindingBundleAnalyzerPluginConfig): BuiltinPlugin;
//#endregion
//#region src/builtin-plugin/transform-plugin.d.ts
type TransformPattern = string | RegExp | readonly (RegExp | string)[];
type TransformPluginConfig = Omit<BindingViteTransformPluginConfig, "include" | "exclude" | "jsxRefreshInclude" | "jsxRefreshExclude" | "yarnPnp"> & {
  include?: TransformPattern;
  exclude?: TransformPattern;
  jsxRefreshInclude?: TransformPattern;
  jsxRefreshExclude?: TransformPattern;
};
export declare function viteTransformPlugin(config: TransformPluginConfig): BuiltinPlugin;
//#endregion
//#region src/builtin-plugin/vite-manifest-plugin.d.ts
type ViteManifestPluginConfig = Omit<BindingViteManifestPluginConfig, "isLegacy"> & {
  isOutputOptionsForLegacyChunks?: (outputOptions: NormalizedOutputOptions) => boolean;
};
export declare function viteManifestPlugin(config: ViteManifestPluginConfig): BuiltinPlugin;
//#endregion
//#region src/experimental-index.d.ts
/**
 * In-memory file system for browser builds.
 *
 * This is a re-export of the {@link https://github.com/streamich/memfs | memfs} package used by the WASI runtime.
 * It allows you to read and write files to a virtual filesystem when using rolldown in browser environments.
 *
 * - `fs`: A Node.js-compatible filesystem API (`IFs` from memfs)
 * - `volume`: The underlying `Volume` instance that stores the filesystem state
 *
 * Returns `undefined` in Node.js builds (only available in browser builds via `@rolldown/browser`).
 *
 * @example
 * ```typescript
 * import { memfs } from 'rolldown/experimental';
 *
 * // Write files to virtual filesystem before bundling
 * memfs?.volume.fromJSON({
 *   '/src/index.js': 'export const foo = 42;',
 *   '/package.json': '{"name": "my-app"}'
 * });
 *
 * // Read files from the virtual filesystem
 * const content = memfs?.fs.readFileSync('/src/index.js', 'utf8');
 * ```
 *
 * @see {@link https://github.com/streamich/memfs} for more information on the memfs API.
 */
export declare const memfs: {
  fs: any;
  volume: any;
} | undefined;
/** @deprecated Use from `rolldown/utils` instead. */
export declare const parse: typeof parse$1;
/** @deprecated Use from `rolldown/utils` instead. */
export declare const parseSync: typeof parseSync$1;
/** @deprecated Use from `rolldown/utils` instead. */
export type ParseResult = ParseResult$1;
/** @deprecated Use from `rolldown/utils` instead. */
export type ParserOptions = ParserOptions$1;
/** @deprecated Use from `rolldown/utils` instead. */
export declare const minify: typeof minify$1;
/** @deprecated Use from `rolldown/utils` instead. */
export declare const minifySync: typeof minifySync$1;
/** @deprecated Use from `rolldown/utils` instead. */
export type MinifyOptions = MinifyOptions$1;
/** @deprecated Use from `rolldown/utils` instead. */
export type MinifyResult = MinifyResult$1;
/** @deprecated Use from `rolldown/utils` instead. */
export declare const transform: typeof transform$1;
/** @deprecated Use from `rolldown/utils` instead. */
export declare const transformSync: typeof transformSync$1;
/** @deprecated Use from `rolldown/utils` instead. */
export type TransformOptions = TransformOptions$1;
/** @deprecated Use from `rolldown/utils` instead. */
export type TransformResult = TransformResult$1;
/** @deprecated Use from `rolldown/utils` instead. */
export declare const TsconfigCache: typeof TsconfigCache$1;
/** @deprecated Use from `rolldown/utils` instead. */
export type TsconfigRawOptions = BindingTsconfigRawOptions;
/** @deprecated Use from `rolldown/utils` instead. */
export type TsconfigCompilerOptions = BindingTsconfigCompilerOptions;
//#endregion
export { type BindingClientHmrUpdate, type BindingNativeMemoryStats, BindingRebuildStrategy, type DevOptions, type DevWatchOptions, type IsolatedDeclarationsOptions, type IsolatedDeclarationsResult, type NapiResolveOptions as ResolveOptions, type ResolveResult, ResolverFactory, defineParallelPlugin, viteDynamicImportVarsPlugin as dynamicImportVarsPlugin, viteDynamicImportVarsPlugin, freeExternalMemory, getNativeMemoryStats, viteImportGlobPlugin as importGlobPlugin, viteImportGlobPlugin, isolatedDeclaration, isolatedDeclarationPlugin, isolatedDeclarationSync, moduleRunnerTransform, oxcRuntimePlugin, resetNativeMemoryStats, resolveTsconfig, viteBuildImportAnalysisPlugin, viteJsonPlugin, viteLoadFallbackPlugin, viteModulePreloadPolyfillPlugin, viteReactRefreshWrapperPlugin, viteReporterPlugin, viteResolvePlugin, viteWebWorkerPostPlugin };