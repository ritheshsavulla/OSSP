import { _ as BindingReplacePluginConfig } from "./shared/binding-CwA4xu8x.mjs";
import { I as BuiltinPlugin } from "./shared/define-config-BLptERXo.mjs";
import { t as esmExternalRequirePlugin } from "./shared/constructors-D9cRAoTT.mjs";
//#region src/builtin-plugin/replace-plugin.d.ts
/**
 * Replaces targeted strings in files while bundling.
 *
 * @example
 * **Basic usage**
 * ```js
 * replacePlugin({
 *   'process.env.NODE_ENV': JSON.stringify('production'),
 *    __buildVersion: 15
 * })
 * ```
 * @example
 * **With options**
 * ```js
 * replacePlugin({
 *   'process.env.NODE_ENV': JSON.stringify('production'),
 *   __buildVersion: 15
 * }, {
 *   preventAssignment: false,
 * })
 * ```
 *
 * @see https://rolldown.rs/builtin-plugins/replace
 * @category Builtin Plugins
 */
export declare function replacePlugin(values?: BindingReplacePluginConfig["values"], options?: Omit<BindingReplacePluginConfig, "values">): BuiltinPlugin;
//#endregion
export { esmExternalRequirePlugin };